// ==UserScript==
// @name           小说自动滚动
// @description    自动滚动脚本. 通过快捷键 PageDown 控制页面平滑滚动, 通过快捷键 PageUp 暂停滚动.
// @version        0.2.0
// @author         Yiero
// @match          https://www.qidian.com/chapter/*
// @match          http://192.168.5.136:1122/*
// @match          http://192.168.5.137:1122/*
// @match          http://192.168.5.138:1122/*
// @tag            novel
// @tag            scroll
// @license        GPL-3
// @namespace      https://github.com/AliubYiero/Yiero_WebScripts
// @noframes
// @grant          GM_getValue
// @grant          GM_setValue
// @grant          GM_deleteValue
// @grant          GM_addValueChangeListener
// @grant          GM_removeValueChangeListener
// ==/UserScript==
/* ==UserConfig==
滚动配置:
    scrollLength:
        title: '滚动距离 (px/s)'
        description: 滚动距离
        type: number
        min: 0
        default: 100
==/UserConfig== */
(function() {
  "use strict";
  let messageContainer = null;
  const messageTypes = {
    success: {
      backgroundColor: "#f0f9eb",
      borderColor: "#e1f3d8",
      textColor: "#67c23a",
      icon: "\u2713"
    },
    warning: {
      backgroundColor: "#fdf6ec",
      borderColor: "#faecd8",
      textColor: "#e6a23c",
      icon: "\u26A0"
    },
    error: {
      backgroundColor: "#fef0f0",
      borderColor: "#fde2e2",
      textColor: "#f56c6c",
      icon: "\u2715"
    },
    info: {
      backgroundColor: "#edf2fc",
      borderColor: "#e4e7ed",
      textColor: "#909399",
      icon: "i"
    }
  };
  const messagePositions = {
    top: {
      top: "20px"
    },
    "top-left": {
      top: "20px",
      left: "20px"
    },
    "top-right": {
      top: "20px",
      right: "20px"
    },
    left: {
      left: "20px"
    },
    right: {
      right: "20px"
    },
    bottom: {
      bottom: "20px"
    },
    "bottom-left": {
      bottom: "20px",
      left: "20px"
    },
    "bottom-right": {
      bottom: "20px",
      right: "20px"
    }
  };
  function createMessageContainer() {
    if (!messageContainer) {
      messageContainer = document.createElement("div");
      messageContainer.setAttribute("style", `
                    position: fixed;
                    z-index: 9999999999;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    pointer-events: none;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    width: 100vw;
                `);
      document.body.appendChild(messageContainer);
    }
    return messageContainer;
  }
  function getAnimationOffset(position, isEnter) {
    const isBottom = position.includes("bottom");
    return isBottom ? 20 : -20;
  }
  function validateMessageOptions(detail) {
    if (!detail.message || "string" != typeof detail.message) throw new Error("Message: message \u53C2\u6570\u5FC5\u987B\u662F\u6709\u6548\u7684\u975E\u7A7A\u5B57\u7B26\u4E32");
    const MIN_DURATION = 100;
    if (void 0 !== detail.duration) {
      if ("number" != typeof detail.duration || detail.duration < MIN_DURATION) throw new Error(`Message: duration \u5FC5\u987B\u662F >= ${MIN_DURATION} \u7684\u6570\u5B57`);
    }
    const validTypes = [
      "success",
      "warning",
      "error",
      "info"
    ];
    if (void 0 !== detail.type && !validTypes.includes(detail.type)) throw new Error(`Message: type \u5FC5\u987B\u662F ${validTypes.join(" | ")} \u4E4B\u4E00`);
    const validPositions = [
      "top",
      "top-left",
      "top-right",
      "left",
      "right",
      "bottom",
      "bottom-left",
      "bottom-right"
    ];
    if (void 0 !== detail.position && !validPositions.includes(detail.position)) throw new Error(`Message: position \u5FC5\u987B\u662F ${validPositions.join(" | ")} \u4E4B\u4E00`);
  }
  const Message = (options) => {
    const detail = {
      type: "info",
      duration: 3e3,
      position: "top"
    };
    if ("string" == typeof options) detail.message = options;
    else Object.assign(detail, options);
    validateMessageOptions(detail);
    messageContainer = createMessageContainer();
    const messageEl = document.createElement("div");
    const messageType = detail.type || "info";
    const messagePosition = detail.position || "top";
    const messageDuration = detail.duration || 3e3;
    const typeConfig = messageTypes[messageType];
    const initialOffset = getAnimationOffset(messagePosition);
    messageEl.setAttribute("style", `
                position: absolute;
                min-width: 300px;
                max-width: 500px;
                padding: 15px 20px;
                border-radius: 8px;
                transform: translateY(${initialOffset}px);
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
                background-color: ${typeConfig.backgroundColor};
                border: 1px solid ${typeConfig.borderColor};
                color: ${typeConfig.textColor};
                display: flex;
                align-items: center;
                transition: all 0.3s ease;
                opacity: 0;
                pointer-events: auto;
                cursor: pointer;
                ${Object.entries(messagePositions[messagePosition]).map(([k, v]) => `${k}: ${v};`).join(" ")}
            `);
    messageEl.setAttribute("role", "alert");
    messageEl.setAttribute("aria-live", "polite");
    messageEl.setAttribute("aria-atomic", "true");
    messageEl.setAttribute("tabindex", "0");
    const iconEl = document.createElement("span");
    iconEl.setAttribute("style", `
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 24px;
                height: 24px;
                margin-right: 12px;
                font-size: 16px;
                font-weight: bold;
            `);
    iconEl.textContent = typeConfig.icon;
    messageEl.appendChild(iconEl);
    const contentEl = document.createElement("span");
    contentEl.setAttribute("style", `
                flex: 1;
                font-size: 14px;
                line-height: 1.5;
            `);
    contentEl.textContent = detail.message;
    messageEl.appendChild(contentEl);
    messageContainer.appendChild(messageEl);
    requestAnimationFrame(() => {
      messageEl.style.opacity = "1";
      messageEl.style.transform = "translateY(0)";
    });
    const timer2 = setTimeout(() => {
      closeMessage(messageEl, messagePosition);
    }, messageDuration);
    messageEl.addEventListener("click", () => {
      clearTimeout(timer2);
      closeMessage(messageEl, messagePosition);
    });
    messageEl.addEventListener("keydown", (e) => {
      if ("Escape" === e.key) {
        clearTimeout(timer2);
        closeMessage(messageEl, messagePosition);
      }
    });
    const close = () => {
      clearTimeout(timer2);
      closeMessage(messageEl, messagePosition);
    };
    return {
      close,
      element: messageEl
    };
  };
  function closeMessage(element, position = "top") {
    const exitOffset = getAnimationOffset(position);
    element.style.opacity = "0";
    element.style.transform = `translateY(${exitOffset}px)`;
    setTimeout(() => {
      if (element.parentNode) element.parentNode.removeChild(element);
    }, 300);
  }
  const messageTypes_shortcuts = [
    "success",
    "warning",
    "error",
    "info"
  ];
  messageTypes_shortcuts.forEach((type) => {
    Message[type] = (message, options) => Message({
      ...options,
      message,
      type
    });
  });
  function onKeydownMultiple(bindings, options) {
    const { target = window, capture = false, passive = false } = {};
    const eventOptions = {
      capture,
      passive
    };
    const handleKeydown = (event) => {
      for (const binding of bindings) {
        const { callback, key, ctrl = false, alt = false, shift = false, meta = false } = binding;
        const hasShortcutFilter = void 0 !== key || ctrl || alt || shift || meta;
        if (hasShortcutFilter) {
          if (void 0 !== key) {
            const eventKey = event.key;
            const expectedKey = key;
            const isMatch = 1 === eventKey.length && 1 === expectedKey.length ? eventKey.toLowerCase() === expectedKey.toLowerCase() : eventKey === expectedKey;
            if (!isMatch) continue;
          }
          if (event.ctrlKey !== ctrl) continue;
          if (event.altKey !== alt) continue;
          if (event.shiftKey !== shift) continue;
          if (event.metaKey !== meta) continue;
        }
        callback(event);
      }
    };
    target.addEventListener("keydown", handleKeydown, eventOptions);
    return () => {
      target.removeEventListener("keydown", handleKeydown, eventOptions);
    };
  }
  class GmStorage {
    key;
    defaultValue;
    listenerId = 0;
    constructor(key, defaultValue) {
      this.key = key;
      this.defaultValue = defaultValue;
      this.key = key;
      this.defaultValue = defaultValue;
    }
    get value() {
      return this.get();
    }
    get() {
      return GM_getValue(this.key, this.defaultValue);
    }
    set(value) {
      return GM_setValue(this.key, value);
    }
    remove() {
      GM_deleteValue(this.key);
    }
    updateListener(callback) {
      this.removeListener();
      this.listenerId = GM_addValueChangeListener(this.key, (key, oldValue, newValue, remote) => {
        callback({
          key,
          oldValue,
          newValue,
          remote
        });
      });
    }
    removeListener() {
      GM_removeValueChangeListener(this.listenerId);
    }
  }
  const scrollLengthStore = new GmStorage("\u6EDA\u52A8\u914D\u7F6E.scrollLength", 100);
  let timer = 0;
  const startScroll = (scrollHeight, scrollTimePerCount) => {
    if (timer) {
      stopScroll();
    }
    timer = window.setInterval(() => {
      scrollBy({
        top: scrollHeight,
        behavior: "smooth"
      });
    }, scrollTimePerCount);
  };
  const stopScroll = () => {
    clearTimeout(timer);
    timer = 0;
  };
  const SCROLL_COUNT_PER_SECOND = 60;
  let currentStatus = 1;
  const getScrollParams = () => {
    const scrollLength = scrollLengthStore.get();
    const scrollHeight = Math.round(scrollLength / SCROLL_COUNT_PER_SECOND);
    const scrollTimePerCount = Math.round(1e3 / SCROLL_COUNT_PER_SECOND);
    return { scrollHeight, scrollTimePerCount, scrollLength };
  };
  const adjustScrollSpeed = (delta) => {
    scrollLengthStore.set(scrollLengthStore.get() + delta);
    const {
      scrollHeight,
      scrollTimePerCount,
      scrollLength
    } = getScrollParams();
    if (currentStatus === 0) {
      stopScroll();
      startScroll(scrollHeight, scrollTimePerCount);
    }
    const action = delta > 0 ? "\u589E\u52A0" : "\u964D\u4F4E";
    Message.info(`${action}\u6EDA\u52A8\u901F\u5EA6, \u6EDA\u52A8\u901F\u5EA6\u4E3A ${scrollLength} px/s`, { position: "top-left" });
  };
  const main = async () => {
    onKeydownMultiple([
      {
        key: "PageDown",
        callback: (e) => {
          e.preventDefault();
          if (currentStatus === 0) {
            return;
          }
          const {
            scrollHeight,
            scrollTimePerCount,
            scrollLength
          } = getScrollParams();
          startScroll(scrollHeight, scrollTimePerCount);
          currentStatus = 0;
          Message.info(`\u5F00\u542F\u6EDA\u52A8, \u6EDA\u52A8\u901F\u5EA6\u4E3A ${scrollLength} px/s`, { position: "top-left" });
        }
      },
      {
        key: "PageUp",
        callback: (e) => {
          e.preventDefault();
          if (currentStatus === 1) {
            return;
          }
          stopScroll();
          currentStatus = 1;
          Message.info(`\u5173\u95ED\u6EDA\u52A8`, { position: "top-left" });
        }
      },
      {
        key: "PageUp",
        shift: true,
        callback: (e) => {
          e.preventDefault();
          adjustScrollSpeed(1);
        }
      },
      {
        key: "PageDown",
        shift: true,
        callback: (e) => {
          e.preventDefault();
          adjustScrollSpeed(-1);
        }
      }
    ]);
    document.addEventListener("visibilitychange", () => {
      if (currentStatus !== 0) {
        return;
      }
      const {
        scrollHeight,
        scrollTimePerCount
      } = getScrollParams();
      document.hidden ? stopScroll() : startScroll(scrollHeight, scrollTimePerCount);
    });
  };
  main().catch(console.error);
})();