// ==UserScript==
// @name           Bilibili 视频时间轴
// @name:en        Bilibili Video Timeline
// @description    根据视频字幕, 生成视频时间轴.
// @version        1.0.1
// @author         Yiero
// @match          https://www.bilibili.com/video/*
// @run-at         document-body
// @connect        hdslb.com
// @license        GPL-3
// @namespace      https://github.com/AliubYiero/TamperMonkeyScripts
// @grant          GM_addStyle
// @grant          GM_registerMenuCommand
// @grant          GM_unregisterMenuCommand
// ==/UserScript==
var __defProp = Object.defineProperty;
var __defNormalProp = ( obj, key, value ) => key in obj ? __defProp( obj, key, {
	enumerable: true,
	configurable: true,
	writable: true,
	value,
} ) : obj[key] = value;
var __publicField = ( obj, key, value ) => __defNormalProp( obj, typeof key !== 'symbol' ? key + '' : key, value );

class MenuCommand {
	constructor( name, callback ) {
		__publicField( this, 'menuId', 0 );
		this.name = name;
		this.callback = callback;
		this.name = name;
		this.callback = callback;
	}
	
	register() {
		this.menuId = GM_registerMenuCommand( this.name, ( e ) => {
			this.callback( e, this );
		} );
	}
	
	remove() {
		GM_unregisterMenuCommand( this.menuId );
	}
}

const getVideoSubtitleData = async ( subtitle ) => {
	const subtitleDate = await fetch( subtitle.subtitle_url ).then( ( r ) => r.json() );
	return subtitleDate.body;
};
const timelineUI = `<!doctype html>
<html lang="zh-cn">
<head>
	<meta charset="UTF-8">
	<meta
		content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0"
		name="viewport">
	<title>Timeline UI</title>
	<link href="timelineUiStyle.css" rel="stylesheet">

</head>
<body>
<div class="timeline-container">
	<header class="timeline-header">
		<h3 class="timeline-title">
			\u65F6\u95F4\u8F74 - \u4E2D\u6587\uFF08\u81EA\u52A8\u751F\u6210\uFF09
		</h3>
		<span class="timeline-video-id">
			av113752863147248 / BV1RE6oYtEaf
		</span>
	</header>
	<main class="timeline-content-container">
		<!-- (section.timeline-item>span.timeline-start-time{\u4E8B\u4EF6$}+span.timeline-content{\u5185\u5BB9$})* 100 -->
	</main>
</div>

</body>
</html>
`;
const timelineItemUi = `<!doctype html>
<html lang="zh-cn">
<head>
	<meta charset="UTF-8">
	<meta
		content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0"
		name="viewport">
	<title>Timeline Item UI</title>
</head>
<body>
<section class="timeline-item">
	<span class="timeline-start-time">\u65F6\u95F4</span>
	<span class="timeline-content">\u5185\u5BB9</span>
</section>
</body>
</html>
`;
const timelineUiStyle = `.timeline-container {
	height: 70vh;
	box-shadow: #d8d8d8 0 0 10px;
	margin-bottom: 24px;
	z-index: 999;
	
	display: flex;
	gap: 8px;
	flex-flow: column;
	border-radius: 4px;
	
	pointer-events: all;
}

.timeline-header {
	position: sticky;
	top: 0;
	display: flex;
	flex-flow: column;
	gap: 4px;
	justify-content: center;
	align-items: center;
	background-color: #fff;
	box-shadow: inherit;
	
	padding: 10px 0;
}

.timeline-title {
	color: #333;
	padding: 0;
	margin: 0;
	font-size: 20px;
}

.timeline-video-id {
	display: flex;
	gap: 10px;
	flex: 1;
	color: #aaaaaa;
	font-size: 14px;
}

.timeline-content-container {
	display: flex;
	gap: 8px;
	flex-flow: column;
	overflow-y: auto;
	scrollbar-width: thin;
}

.timeline-item {
	display: flex;
	gap: 8px;
	padding: 0 16px;
	border-radius: 8px;
	font-size: 14px;
	align-items: center;
}

.timeline-item:hover {
	background: #ddffff;
}

.timeline-start-time {
	color: #aaa;
	font-size: 12px;
	min-width: 4em;
}

.timeline-content {
	color: #333;
}
`;
const uiCreator = ( htmlContent, cssContent ) => {
	if ( cssContent ) {
		GM_addStyle( cssContent );
	}
	const domParser = new DOMParser();
	const uiDoc = domParser.parseFromString( htmlContent, 'text/html' );
	const documentFragment = new DocumentFragment();
	const filterScriptNodeList = Array.from( uiDoc.body.children ).filter( ( node ) => node.nodeName !== 'SCRIPT' );
	documentFragment.append( ...filterScriptNodeList );
	return documentFragment;
};

/*
* @module      : @yiero/gmlib
* @author      : Yiero
* @version     : 0.1.5
* @description : GM Lib for Tampermonkey
* @keywords    : tampermonkey, lib, scriptcat, utils
* @license     : MIT
* @repository  : git+https://github.com/AliubYiero/GmLib.git
*/
function elementWaiter( selector, config = {} ) {
	const {
		parent = document.body,
		timeoutPerSecond = 20,
		delayPerSecond = 0.5,
	} = config;
	return new Promise( ( resolve, reject ) => {
		const returnElement = ( selector2 ) => {
			setTimeout( () => {
				const element2 = document.querySelector( selector2 );
				if ( !element2 ) {
					reject( new Error( 'Void Element' ) );
					return;
				}
				window.dispatchEvent( new CustomEvent( 'ElementUpdate', { detail: element2 } ) );
				resolve( element2 );
			}, delayPerSecond * 1e3 );
		};
		const element = document.querySelector( selector );
		if ( element ) {
			returnElement( selector );
			return;
		}
		if ( MutationObserver ) {
			const timer2 = timeoutPerSecond && window.setTimeout( () => {
				observer.disconnect();
				returnElement( selector );
			}, timeoutPerSecond * 1e3 );
			const observeElementCallback = ( mutations ) => {
				mutations.forEach( ( mutation ) => {
					mutation.addedNodes.forEach( ( addNode ) => {
						if ( addNode.nodeType !== Node.ELEMENT_NODE ) {
							return;
						}
						const addedElement = addNode;
						const element2 = addedElement.matches( selector ) ? addedElement : addedElement.querySelector( selector );
						if ( element2 ) {
							timer2 && clearTimeout( timer2 );
							returnElement( selector );
						}
					} );
				} );
			};
			const observer = new MutationObserver( observeElementCallback );
			observer.observe( parent, {
				subtree: true,
				childList: true,
			} );
			return;
		}
		const intervalDelay = 100;
		let intervalCounter = 0;
		const maxIntervalCounter = Math.ceil( timeoutPerSecond * 1e3 / intervalDelay );
		const timer = window.setInterval( () => {
			if ( ++intervalCounter > maxIntervalCounter ) {
				clearInterval( timer );
				returnElement( selector );
				return;
			}
			const element2 = parent.querySelector( selector );
			if ( element2 ) {
				clearInterval( timer );
				returnElement( selector );
			}
		}, intervalDelay );
	} );
}

const timelineItemUIEvent = ( timelineItem, subtitleData ) => {
	timelineItem.addEventListener( 'click', () => {
		elementWaiter( 'video', {
			delayPerSecond: 0.05,
		} ).then( ( video ) => {
			video.currentTime = subtitleData.from;
		} );
	} );
};
const hookXhr = ( hookUrl, callback ) => {
	const xhrOpen = XMLHttpRequest.prototype.open;
	XMLHttpRequest.prototype.open = function () {
		const xhr = this;
		if ( hookUrl( arguments[1] ) ) {
			const getter = Object.getOwnPropertyDescriptor(
				XMLHttpRequest.prototype,
				'responseText',
			).get;
			Object.defineProperty( xhr, 'responseText', {
				get: () => {
					let result = getter.call( xhr );
					callback( result, arguments[1] );
					return result;
				},
			} );
		}
		return xhrOpen.apply( xhr, arguments );
	};
};
const freshMenuCommand = async ( menuCommandList, self ) => {
	menuCommandList.forEach( ( menuCommand ) => menuCommand.remove() );
	for ( let i = 0; i < menuCommandList.length; i++ ) {
		menuCommandList.shift();
	}
	self.register();
	const commandList = await registerTimeline();
	menuCommandList.push( self, ...commandList );
};
let TimelineMenuCommand$1 = [];
const FreshMenuCommand$1 = new MenuCommand( '\u5237\u65B0', async ( _, self ) => {
	await freshMenuCommand(
		TimelineMenuCommand$1,
		self,
	);
} );
( async () => {
	handleHookBaseInfo();
	await elementWaiter( '.up-panel-container' );
	FreshMenuCommand$1.register();
	TimelineMenuCommand$1 = [ FreshMenuCommand$1, ...await registerTimeline() ];
} )();
const removeTimelineContainer = () => {
	const timelineContainer = document.querySelector( '.timeline-container' );
	timelineContainer && timelineContainer.remove();
};
let playerInfo;
const handleHookBaseInfo = () => {
	hookXhr(
		( url ) => {
			return url.startsWith( 'https://api.bilibili.com/x/player/wbi/v2' ) || url.startsWith( '//api.bilibili.com/x/player/wbi/v2' );
		},
		async ( responseText ) => {
			playerInfo = JSON.parse( responseText );
			removeTimelineContainer();
			await freshMenuCommand(
				TimelineMenuCommand$1,
				FreshMenuCommand$1,
			);
		},
	);
};
const timelineUiImporter = async ( subtitleDataList, subtitleTitle ) => {
	const containerDocumentFragment = uiCreator( timelineUI, timelineUiStyle );
	const timelineContainer = containerDocumentFragment.querySelector( '.timeline-container' );
	if ( !timelineContainer ) {
		return;
	}
	const timelineContentContainer = timelineContainer.querySelector( '.timeline-content-container' );
	if ( !timelineContentContainer ) {
		return;
	}
	const itemDocumentFragment = uiCreator( timelineItemUi );
	const timelineItem = itemDocumentFragment.querySelector( '.timeline-item' );
	if ( !timelineItem ) {
		return;
	}
	const title = timelineContainer.querySelector( '.timeline-title' );
	const videoId = timelineContainer.querySelector( '.timeline-video-id' );
	if ( !title || !videoId ) {
		return;
	}
	title.textContent = `\u65F6\u95F4\u8F74 - ${ subtitleTitle }`;
	const { aid, bvid } = playerInfo.data;
	videoId.textContent = `av${ aid } / ${ bvid }`;
	const subtitleContentList = subtitleDataList.map( ( subtitleData ) => {
		const date = new Date( subtitleData.from * 1e3 );
		const startTime = [
			date.getUTCHours(),
			date.getUTCMinutes(),
			date.getUTCSeconds(),
		].map( ( time ) => time.toString().padStart( 2, '0' ) ).join( ':' ) + `.${ Math.round( date.getUTCMilliseconds() / 10 ).toString().padStart( 2, '0' ) }`;
		const content = subtitleData.content;
		const addedTimelineItem = timelineItem.cloneNode( true );
		const addedTimeNode = addedTimelineItem.querySelector( '.timeline-start-time' );
		const addedContentNode = addedTimelineItem.querySelector( '.timeline-content' );
		if ( !addedTimeNode || !addedContentNode ) {
			throw new Error( '\u65E0\u6CD5\u89E3\u6790\u5230 .timeline-start-time / .timeline-content \u5143\u7D20' );
		}
		addedTimeNode.textContent = startTime;
		addedContentNode.textContent = content;
		timelineItemUIEvent( addedTimelineItem, subtitleData );
		return addedTimelineItem;
	} );
	timelineContentContainer.append( ...subtitleContentList );
	const rightContainer = await elementWaiter( '.right-container-inner' );
	const rightItemList = Array.from( document.querySelectorAll( '.right-container-inner > *' ) );
	const newRightItemList = [ rightItemList[0], timelineContainer, ...rightItemList.slice( 1 ) ];
	newRightItemList.forEach( ( item ) => {
		rightContainer.append( item );
	} );
};
const createTimeline = async ( subtitle ) => {
	const subtitleDataList = await getVideoSubtitleData( subtitle );
	await timelineUiImporter( subtitleDataList, subtitle.lan_doc );
};
const registerTimeline = async () => {
	const videoSubtitleList = playerInfo.data.subtitle.subtitles;
	if ( !videoSubtitleList.length ) {
		return [];
	}
	return videoSubtitleList.map( ( subtitle ) => {
		const TimeLineMenuCommand = new MenuCommand( `\u751F\u6210\u89C6\u9891\u65F6\u95F4\u8F74 - ${ subtitle.lan_doc }`, async () => {
			removeTimelineContainer();
			await createTimeline( subtitle );
		} );
		TimeLineMenuCommand.register();
		return TimeLineMenuCommand;
	} );
};
let TimelineMenuCommand = [];
const FreshMenuCommand = new MenuCommand( '\u5237\u65B0', async ( _, self ) => {
	await freshMenuCommand(
		TimelineMenuCommand,
		self,
	);
} );
( async () => {
	handleHookBaseInfo();
	await elementWaiter( '.up-panel-container' );
	FreshMenuCommand.register();
	TimelineMenuCommand = [ FreshMenuCommand, ...await registerTimeline() ];
} )();
