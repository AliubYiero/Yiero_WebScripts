// ==UserScript==
// @name           Bilibili 视频时间轴
// @name:en        Bilibili Video Timeline
// @description    根据视频字幕, 生成视频时间轴. 
// @version        1.2.2
// @author         Yiero
// @match          https://www.bilibili.com/video/*
// @run-at         document-start
// @connect        hdslb.com
// @license        GPL-3
// @namespace      https://github.com/AliubYiero/TamperMonkeyScripts
// @grant          GM_addStyle
// @grant          GM_registerMenuCommand
// @grant          GM_unregisterMenuCommand
// @grant          GM_setClipboard
// @grant          GM_setValue
// @grant          GM_getValue
// @grant          GM_deleteValue
// ==/UserScript==
/* ==UserConfig==
配置项:
    alwaysLoad:
        title: 自动加载时间轴
        description: '页面载入时, 自动加载时间轴到页面中'
        type: checkbox
        default: false
    copyTime:
        title: 自动复制时间
        description: '点击时间的时候, 自动复制时间到粘贴板'
        type: checkbox
        default: false
    copyContent:
        title: 自动复制文本
        description: '点击文本的时候, 自动复制文本到粘贴板'
        type: checkbox
        default: false
==/UserConfig== */
var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
class MenuCommand {
  constructor(name, callback) {
    __publicField(this, "menuId", 0);
    this.name = name;
    this.callback = callback;
    this.name = name;
    this.callback = callback;
  }
  /**
   * 注册菜单
   */
  register() {
    this.menuId = GM_registerMenuCommand(this.name, (e) => {
      this.callback(e, this);
    });
  }
  /**
   * 手动激活回调函数
   */
  click() {
    this.callback(void 0, this);
  }
  /**
   * 移除菜单
   */
  remove() {
    GM_unregisterMenuCommand(this.menuId);
  }
}
const getVideoSubtitleData = async (subtitle) => {
  const subtitleDate = await fetch(subtitle.subtitle_url).then((r) => r.json());
  return subtitleDate.body;
};
const timelineUI = `<!doctype html>
<html lang="zh-cn">
<head>
	<meta charset="UTF-8">
	<meta
		content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0"
		name="viewport">
	<title>Timeline UI</title>
	<link href="timelineUiStyle.css" rel="stylesheet">

</head>
<body>
<div class="timeline-container">
	<header class="timeline-header">
		<h3 class="timeline-title">
			\u65F6\u95F4\u8F74 - \u4E2D\u6587\uFF08\u81EA\u52A8\u751F\u6210\uFF09
		</h3>
		<section class="timeline-sub-title-container">
			<button class="timeline-active-center-button">
				<span>\u65F6\u95F4\u8F74\u5C45\u4E2D</span>
				<span
					class="timeline-active-button">(on)</span>
				<span class="timeline-not-active-button">(off)</span>
			</button>
			<span class="timeline-video-id">
				<span class="timeline-video-aid">av113752863147248</span>
				<span class="timeline-video-bvid">BV1RE6oYtEaf</span>
			</span>
		</section>
	</header>
	<main class="timeline-content-container">
		<!-- (section.timeline-item>span.timeline-start-time{\u4E8B\u4EF6$}+span.timeline-content{\u5185\u5BB9$})* 100 -->
	</main>
</div>

</body>
</html>
`;
const timelineItemUi = `<!doctype html>
<html lang="zh-cn">
<head>
	<meta charset="UTF-8">
	<meta
		content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0"
		name="viewport">
	<title>Timeline Item UI</title>
</head>
<body>
<section class="timeline-item">
	<span class="timeline-start-time">\u65F6\u95F4</span>
	<span class="timeline-content">\u5185\u5BB9</span>
</section>
</body>
</html>
`;
const timelineUiStyle = `/* \u4E3B\u5BB9\u5668 */
.timeline-container {
	height: 70vh;
	box-shadow: #d8d8d8 0 0 10px;
	margin-bottom: 24px;
	z-index: 999;
	
	display: flex;
	gap: 8px;
	flex-flow: column;
	border-radius: 4px;
	
	pointer-events: all;
}

/* \u5934\u90E8\u5BB9\u5668 */
.timeline-header {
	position: sticky;
	top: 0;
	display: flex;
	flex-flow: column;
	gap: 4px;
	justify-content: center;
	align-items: center;
	background-color: #fff;
	box-shadow: inherit;
	
	padding: 10px 0;
}

/* \u6807\u9898 */
.timeline-title {
	color: #333;
	padding: 0;
	margin: 0;
	font-size: 20px;
}

/* \u526F\u6807\u9898 */
.timeline-sub-title-container {
	display: flex;
	align-items: center;
	justify-content: space-between;
	width: 90%;
	gap: 5vw;
}

/* \u526F\u6807\u9898 (\u89C6\u9891\u7F16\u53F7) */
.timeline-video-id {
	color: #aaaaaa;
	font-size: 12px;
	
	display: flex;
	flex-flow: column;
	justify-content: right;
	align-items: flex-end;
}

/* \u526F\u6807\u9898 (\u65F6\u95F4\u8F74\u5C45\u4E2D\u6309\u94AE - \u5173\u95ED\u72B6\u6001) */
.timeline-active-center-button {
	font-size: 12px;
	padding: 4px 8px;
	outline: none;
	border: none;
	border-radius: 5px;
	background-color: #444;
	color: #ccffff;
}

.timeline-active-center-button:hover {
	box-shadow: #aaa 0 0 10px;
}

/* \u526F\u6807\u9898 (\u65F6\u95F4\u8F74\u5C45\u4E2D\u6309\u94AE - \u5F00\u542F\u72B6\u6001) */
.timeline-active-center-button.active {
	background-color: #ccffff;
	color: #444;
}

.timeline-active-button {
	display: none;
}

.timeline-not-active-button {
	display: initial;
}

.timeline-active-center-button.active {
	& .timeline-active-button {
		display: initial;
	}
	
	& .timeline-not-active-button {
		display: none;
	}
}

/* \u65F6\u95F4\u8F74\u5BB9\u5668 */
.timeline-content-container {
	display: flex;
	gap: 8px;
	flex-flow: column;
	overflow-y: auto;
	scrollbar-width: thin;
}

/* \u65F6\u95F4\u8F74\u9879 */
.timeline-item {
	display: flex;
	gap: 8px;
	padding: 0 16px;
	border-radius: 4px;
	font-size: 14px;
	align-items: center;
}

/* \u6FC0\u6D3B\u7684\u65F6\u95F4\u8F74 */
.timeline-item.active {
	background-color: #ccffff;
	padding: 4px 16px;
	margin: 4px 0;
	font-size: 16px;
}

/* \u9AD8\u4EAE\u663E\u793A\u9F20\u6807\u6D6E\u52A8\u7684\u65F6\u95F4\u8F74 */
.timeline-item:hover {
	background: #ddffff;
}

/* \u65F6\u95F4\u8F74 (\u5F00\u59CB\u65F6\u95F4) */
.timeline-start-time {
	color: #aaa;
	font-size: 12px;
	min-width: 4em;
}

/* \u65F6\u95F4\u8F74 (\u6587\u672C) */
.timeline-content {
	color: #333;
}
`;
const uiCreator = (htmlContent, cssContent) => {
  if (cssContent) {
    GM_addStyle(cssContent);
  }
  const domParser = new DOMParser();
  const uiDoc = domParser.parseFromString(htmlContent, "text/html");
  const documentFragment = new DocumentFragment();
  const filterScriptNodeList = Array.from(uiDoc.body.children).filter((node) => node.nodeName !== "SCRIPT");
  documentFragment.append(...filterScriptNodeList);
  return documentFragment;
};
/*
* @module      : @yiero/gmlib
* @author      : Yiero
* @version     : 0.1.7
* @description : GM Lib for Tampermonkey
* @keywords    : tampermonkey, lib, scriptcat, utils
* @license     : MIT
* @repository  : git+https://github.com/AliubYiero/GmLib.git
*/
const isIframe = () => {
  return Boolean(
    window.frameElement && window.frameElement.tagName === "IFRAME" || window !== window.top
  );
};
function elementWaiter(selector, config = {}) {
  const {
    parent = document.body,
    timeoutPerSecond = 20,
    delayPerSecond = 0.5
  } = config;
  return new Promise((resolve, reject) => {
    const returnElement = (selector2) => {
      setTimeout(() => {
        const element2 = parent.querySelector(selector2);
        if (!element2) {
          reject(new Error("Void Element"));
          return;
        }
        window.dispatchEvent(new CustomEvent("ElementUpdate", { detail: element2 }));
        resolve(element2);
      }, delayPerSecond * 1e3);
    };
    const element = parent.querySelector(selector);
    if (element) {
      returnElement(selector);
      return;
    }
    if (MutationObserver) {
      const timer2 = timeoutPerSecond && window.setTimeout(() => {
        observer.disconnect();
        returnElement(selector);
      }, timeoutPerSecond * 1e3);
      const observeElementCallback = (mutations) => {
        mutations.forEach((mutation) => {
          mutation.addedNodes.forEach((addNode) => {
            if (addNode.nodeType !== Node.ELEMENT_NODE) {
              return;
            }
            const addedElement = addNode;
            const element2 = addedElement.matches(selector) ? addedElement : addedElement.querySelector(selector);
            if (element2) {
              timer2 && clearTimeout(timer2);
              returnElement(selector);
            }
          });
        });
      };
      const observer = new MutationObserver(observeElementCallback);
      observer.observe(parent, {
        subtree: true,
        childList: true
      });
      return;
    }
    const intervalDelay = 100;
    let intervalCounter = 0;
    const maxIntervalCounter = Math.ceil(timeoutPerSecond * 1e3 / intervalDelay);
    const timer = window.setInterval(() => {
      if (++intervalCounter > maxIntervalCounter) {
        clearInterval(timer);
        returnElement(selector);
        return;
      }
      const element2 = parent.querySelector(selector);
      if (element2) {
        clearInterval(timer);
        returnElement(selector);
      }
    }, intervalDelay);
  });
}
const hookXhr = (hookUrl, callback) => {
  const xhrOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function() {
    const xhr = this;
    if (hookUrl(arguments[1])) {
      const getter = Object.getOwnPropertyDescriptor(
        XMLHttpRequest.prototype,
        "responseText"
      ).get;
      Object.defineProperty(xhr, "responseText", {
        get: () => {
          let result = getter.call(xhr);
          callback(result, arguments[1]);
          return result;
        }
      });
    }
    return xhrOpen.apply(xhr, arguments);
  };
};
const removeTimelineContainer = () => {
  const timelineContainer = document.querySelector(".timeline-container");
  timelineContainer && timelineContainer.remove();
};
const freshMenuCommand = async (menuCommandList, self) => {
  menuCommandList.forEach((menuCommand) => menuCommand.remove());
  for (let i = 0; i < menuCommandList.length; i++) {
    menuCommandList.shift();
  }
  self.register();
  const commandList = await registerTimeline();
  menuCommandList.push(self, ...commandList);
};
let TimelineMenuCommand = [];
const FreshMenuCommand = new MenuCommand("\u5237\u65B0", async (_, self) => {
  await freshMenuCommand(
    TimelineMenuCommand,
    self
  );
});
class GMStorage {
  constructor(key, defaultValue) {
    this.key = key;
    this.defaultValue = defaultValue;
    this.key = key;
    this.defaultValue = defaultValue;
  }
  /**
   * 获取当前存储的值
   */
  get() {
    return GM_getValue(this.key, this.defaultValue);
  }
  /**
   * 给当前存储设置一个新值
   */
  set(value) {
    return GM_setValue(this.key, value);
  }
  /**
   * 添加 值 到当前储存的数组尾部.
   *
   * @warn 只能在储存值是数组时使用.
   */
  add(appendValue) {
    const list = this.get();
    if (!Array.isArray(list)) {
      return;
    }
    list.push(appendValue);
    this.set(list);
  }
  /**
   * 移除当前键
   */
  remove() {
    GM_deleteValue(this.key);
  }
}
const CenterTimelineStorage = new GMStorage("centerTimeline", true);
const AlwaysLoadStorage = new GMStorage("\u914D\u7F6E\u9879.alwaysLoad", true);
const CopyTimeStorage = new GMStorage("\u914D\u7F6E\u9879.copyTime", true);
const CopyContentStorage = new GMStorage("\u914D\u7F6E\u9879.copyContent", true);
let playerInfo;
const handleHookBaseInfo = () => {
  hookXhr(
    (url) => {
      return url.startsWith("https://api.bilibili.com/x/player/wbi/v2") || url.startsWith("//api.bilibili.com/x/player/wbi/v2");
    },
    async (responseText) => {
      playerInfo = JSON.parse(responseText);
      removeTimelineContainer();
      FreshMenuCommand.click();
      if (AlwaysLoadStorage.get()) {
        elementWaiter(".rcmd-tab", { delayPerSecond: 1 }).then(() => {
          TimelineMenuCommand[1].click();
        });
      }
    }
  );
};
const timelineUIEvent = async (timelineContainer) => {
  const timelineActiveButton = await elementWaiter(
    ".timeline-active-center-button",
    { parent: timelineContainer, delayPerSecond: 0 }
  );
  const centerTimelineStat = CenterTimelineStorage.get();
  centerTimelineStat && timelineActiveButton.classList.add("active");
  const isCopyTime = CopyTimeStorage.get();
  const isCopyContent = CopyContentStorage.get();
  const videoContainer = await elementWaiter("video");
  timelineContainer.addEventListener("click", (e) => {
    const element = e.target;
    if (element.closest(".timeline-active-center-button")) {
      timelineActiveButton.classList.toggle("active");
      CenterTimelineStorage.set(!CenterTimelineStorage.get());
    }
    const timelineItem = element.closest(".timeline-item");
    if (timelineItem) {
      videoContainer.currentTime = Number(timelineItem.dataset.from) || 0;
    }
    if (isCopyTime && element.classList.contains("timeline-start-time")) {
      GM_setClipboard(element.textContent || "");
    }
    if (isCopyContent && element.classList.contains("timeline-content")) {
      GM_setClipboard(element.textContent || "");
    }
  });
};
const timelineUiImporter = async (subtitleDataList, subtitleTitle) => {
  const containerDocumentFragment = uiCreator(timelineUI, timelineUiStyle);
  const timelineContainer = await elementWaiter(
    ".timeline-container",
    { parent: containerDocumentFragment, delayPerSecond: 0 }
  );
  const timelineContentContainer = await elementWaiter(
    ".timeline-content-container",
    { parent: timelineContainer, delayPerSecond: 0 }
  );
  const title = await elementWaiter(".timeline-title", {
    parent: timelineContainer,
    delayPerSecond: 0
  });
  title.textContent = `\u65F6\u95F4\u8F74 - ${subtitleTitle}`;
  const videoAid = await elementWaiter(".timeline-video-aid", {
    parent: timelineContainer,
    delayPerSecond: 0
  });
  const { aid, bvid } = playerInfo.data;
  const videoBvId = await elementWaiter(".timeline-video-bvid", {
    parent: timelineContainer,
    delayPerSecond: 0
  });
  videoAid.textContent = `av${aid}`;
  videoBvId.textContent = bvid;
  const itemDocumentFragment = uiCreator(timelineItemUi);
  const timelineItem = await elementWaiter(".timeline-item", {
    parent: itemDocumentFragment,
    delayPerSecond: 0
  });
  const timelineHtmlContent = timelineItem.outerHTML;
  const subtitleContentList = [];
  for (const subtitleData of subtitleDataList) {
    const date = new Date(subtitleData.from * 1e3);
    const startTime = [
      date.getUTCHours(),
      date.getUTCMinutes(),
      date.getUTCSeconds()
    ].map((time) => time.toString().padStart(2, "0")).join(":") + `.${Math.round(date.getUTCMilliseconds() / 10).toString().padStart(2, "0")}`;
    const content = subtitleData.content;
    let addedTimelineItemHtmlContent = timelineHtmlContent;
    [["\u65F6\u95F4", startTime], ["\u5185\u5BB9", content]].forEach(([replacer, replaceValue]) => {
      addedTimelineItemHtmlContent = addedTimelineItemHtmlContent.replace(replacer, replaceValue);
    });
    const datasetInfoList = [];
    for (let subtitleDataKey in subtitleData) {
      const subtitleDataValue = subtitleData[subtitleDataKey];
      datasetInfoList.push(`data-${subtitleDataKey}="${subtitleDataValue}"`);
    }
    addedTimelineItemHtmlContent = addedTimelineItemHtmlContent.replace(new RegExp('(?<=<section class="timeline-item")'), ` ${datasetInfoList.join(" ")}`);
    subtitleContentList.push(addedTimelineItemHtmlContent);
  }
  timelineContentContainer.innerHTML = subtitleContentList.join("");
  const rightContainer = await elementWaiter(".right-container-inner");
  const rightItemList = Array.from(document.querySelectorAll(".right-container-inner > *"));
  const upInfoContainer = await elementWaiter(".up-info-container", { delayPerSecond: 0 });
  const newRightItemList = [
    upInfoContainer,
    timelineContainer,
    ...rightItemList.filter((item) => !item.classList.contains("up-info-container"))
  ];
  newRightItemList.forEach((item) => {
    rightContainer.append(item);
  });
  await timelineUIEvent(timelineContainer);
  return {
    container: timelineContainer,
    contentContainer: timelineContentContainer,
    itemList: Array.from(timelineContentContainer.querySelectorAll(".timeline-item"))
  };
};
const createTimeline = async (subtitle) => {
  const subtitleDataList = await getVideoSubtitleData(subtitle);
  const uiTarget = await timelineUiImporter(subtitleDataList, subtitle.lan_doc);
  const {
    contentContainer: timelineContentContainer,
    itemList: timelineItemList
  } = uiTarget;
  elementWaiter("video").then((video) => {
    let currentIndex = 0;
    video.addEventListener("timeupdate", () => {
      const startTime = subtitleDataList[currentIndex].from;
      const nextStartTime = subtitleDataList[currentIndex + 1].from || startTime;
      const nextNextStartTime = subtitleDataList[currentIndex + 2].from || startTime;
      const { currentTime } = video;
      if (currentTime >= startTime && currentTime < nextStartTime) {
        const { classList } = timelineItemList[currentIndex];
        !classList.contains("active") && classList.add("active");
        return;
      } else if (currentTime >= nextStartTime && currentTime < nextNextStartTime) {
        timelineItemList[currentIndex].classList.remove("active");
        timelineItemList[++currentIndex].classList.add("active");
      } else {
        timelineItemList[currentIndex].classList.remove("active");
        const currentSubtitle = subtitleDataList.find((subtitleData) => currentTime <= subtitleData.from);
        if (!currentSubtitle) return;
        currentIndex = currentSubtitle.sid - 1;
        timelineItemList[currentIndex].classList.add("active");
      }
      const centerTimelineStat = CenterTimelineStorage.get();
      if (!centerTimelineStat) return;
      const timelineContentContainerDomRect = timelineContentContainer.getBoundingClientRect();
      const activeTimelineItemDomRect = timelineItemList[currentIndex].getBoundingClientRect();
      const yOffset = activeTimelineItemDomRect.top - timelineContentContainerDomRect.top - timelineContentContainerDomRect.height / 2;
      timelineContentContainer.scrollBy({
        top: yOffset,
        behavior: "smooth"
      });
    });
  });
};
const registerTimeline = async () => {
  if (!playerInfo) return Promise.resolve([]);
  const videoSubtitleList = playerInfo.data.subtitle.subtitles;
  if (!videoSubtitleList.length) {
    return [];
  }
  return videoSubtitleList.map((subtitle) => {
    const TimeLineMenuCommand = new MenuCommand(`\u751F\u6210\u89C6\u9891\u65F6\u95F4\u8F74 - ${subtitle.lan_doc}`, async () => {
      /* @__PURE__ */ (() => {
      })(subtitle.lan_doc);
      removeTimelineContainer();
      await createTimeline(subtitle);
    });
    TimeLineMenuCommand.register();
    return TimeLineMenuCommand;
  });
};
(async () => {
  if (isIframe()) {
    return;
  }
  handleHookBaseInfo();
  await elementWaiter(".up-panel-container", { parent: document });
  FreshMenuCommand.register();
  TimelineMenuCommand.push(FreshMenuCommand, ...await registerTimeline());
})();
